// app/api/_mail_test/route.ts
import { NextResponse } from 'next/server'
import { sendEmail } from '@/lib/mailer'

export const runtime = 'nodejs'

export async function GET() {
  try {
    // שנה כתובת לפי הצורך, או הגדר TEST_TO ב-.env
    const to = process.env.TEST_TO || 'hgmeir@gmail.com'
    const result = await sendEmail({
      to,
      subject: 'NeedMe test ✔',
      html: `<p>שלום! זה מייל בדיקה מהשרת המקומי.</p>`
    })
    console.log('[mail_test] result:', result)
    return NextResponse.json({ ok: true, to, result })
  } catch (e: any) {
    console.error('[mail_test] error:', e?.message || e)
    return NextResponse.json({ ok: false, error: String(e?.message || e) }, { status: 500 })
  }
}
