// lib/mailer.ts
import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY);

// אם מוגדר RESEND_TEST_TO – כל השליחות יופנו לשם (מצב בדיקות)
const FORCE_TO = (process.env.RESEND_TEST_TO || '').trim();

export async function sendEmail(to: string, subject: string, body: string) {
  try {
    const from = process.env.MAIL_FROM || 'NeedMe <onboarding@resend.dev>';

    // Resend דורש string (לא אובייקט). נשתמש באובררייד אם קיים.
    const toAddr = FORCE_TO || to;

    const res = await resend.emails.send({
      from,
      to: toAddr,          // חייב להיות string
      subject,
      text: body,          // לטקסט פשוט. אם תרצה HTML: html: body
    });

    return { ok: true, id: (res as any)?.id ?? null };
  } catch (e: any) {
    // רואים שגיאות כמו "You can only send testing emails…"
    return { ok: false, error: e?.message ?? 'send failed' };
  }
}
