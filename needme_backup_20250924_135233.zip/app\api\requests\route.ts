// File: app/api/requests/route.ts
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { sendEmail } from '@/lib/mailer';

export const runtime = 'nodejs';

type Category = 'service' | 'real_estate' | 'second_hand';
type ContactWindow = 'immediate' | 'today' | 'this_week';

type MatchableProvider = {
  id: string;
  email: string;
  categories: string; // שמור כטקסט מופרד '|' ב־DB
  regions: string;    // idem
  tags?: string | null;
  minBudget?: number | null;
  maxBudget?: number | null;
  active: boolean;
  orgName?: string | null;
};

/** ---- עוזר לקריאת גוף הבקשה (Form / JSON) ---- */
async function readBody(req: Request) {
  const ctype = req.headers.get('content-type') || '';
  if (ctype.includes('application/x-www-form-urlencoded')) {
    const text = await req.text();
    const params = new URLSearchParams(text);
    return Object.fromEntries(params.entries());
  }
  if (ctype.includes('multipart/form-data')) {
    const fd = await req.formData();
    const obj: Record<string, any> = {};
    for (const [k, v] of fd.entries()) obj[k] = typeof v === 'string' ? v : v.name;
    return obj;
  }
  if (ctype.includes('application/json')) {
    try { return await req.json(); } catch { return null; }
  }
  return null;
}

export async function OPTIONS() {
  return NextResponse.json({}, { status: 200 });
}

/** ---- דה־דופליקציה לפי אימייל ---- */
function dedupeByEmail<T extends { email?: string | null }>(arr: T[]): T[] {
  const map = new Map<string, T>();
  for (const item of arr) {
    const key = (item.email || '').trim().toLowerCase();
    if (!key) continue;
    if (!map.has(key)) map.set(key, item);
  }
  return [...map.values()];
}

/** ---- התאמת ספקים בסיסית (עובד עם שדות טקסט מופרדים ב־'|') ---- */
function matchProviders(
  req: {
    category: Category;
    subcategory?: string;
    region: string;
    budgetMax?: number;
    title?: string;
  },
  providers: MatchableProvider[],
) {
  const regionNorm = req.region.trim();
  const titleLC = (req.title || '').toLowerCase();

  return providers.filter((p) => {
    if (!p.active) return false;

    const pCats = String(p.categories || '')
      .split('|')
      .map((s) => s.trim())
      .filter(Boolean);

    const pRegs = String(p.regions || '')
      .split('|')
      .map((s) => s.trim())
      .filter(Boolean);

    // קטגוריה ואזור חייבים להתאים
    if (!pCats.includes(req.category)) return false;
    if (!pRegs.includes(regionNorm)) return false;

    // בדיקת תקציב מקסימלי (אם קיים) מול סף מינימלי של הספק
    if (typeof req.budgetMax === 'number' && p.minBudget != null) {
      if (p.minBudget! > req.budgetMax) return false;
    }

    // התאמה רכה לפי תת־קטגוריה/כותרת מול תגיות (אם קיימות)
    if ((req.subcategory || titleLC) && p.tags) {
      const tagsLC = p.tags.toLowerCase();
      const subLC = (req.subcategory || '').toLowerCase();
      if (subLC && !tagsLC.includes(subLC)) {
        // אם אין פגיעה בתת־קטגוריה ננסה בכותרת
        if (titleLC && !tagsLC.includes(titleLC)) {
          // לא לפסול — זה תנאי רך, נשאיר כ־true
        }
      }
    }

    return true;
  });
}

export async function POST(req: Request) {
  const raw = await readBody(req);
  if (!raw || typeof raw !== 'object') {
    return NextResponse.json({ ok: false, error: 'no-body', hint: 'send FormData or JSON' }, { status: 400 });
  }

  const live = String((raw as any).live ?? '1') === '1';

  // שדות
  const title = String((raw as any).title ?? '').trim();
  const category = String((raw as any).category ?? '').trim() as Category;
  const subcategory = String((raw as any).subcategory ?? '').trim();
  const budgetMin = (raw as any).budgetMin ? Number((raw as any).budgetMin) : null;
  const budgetMax = (raw as any).budgetMax ? Number((raw as any).budgetMax) : null;
  const region = String((raw as any).region ?? '').trim();
  const contactWindow = (String((raw as any).contactWindow ?? 'today').trim() || 'today') as ContactWindow;
  const requesterName = String((raw as any).requesterName ?? '').trim();
  const requesterEmail = String((raw as any).requesterEmail ?? '').trim();
  const requesterPhone = (String((raw as any).requesterPhone ?? '').trim() || null) as string | null;

  // ולידציה
  const missing: string[] = [];
  if (!title || title.length < 4) missing.push('title');
  if (!category) missing.push('category');
  if (!region) missing.push('region');
  if (!requesterName) missing.push('requesterName');
  if (!/^\S+@\S+\.\S+$/.test(requesterEmail)) missing.push('requesterEmail');
  if (missing.length) {
    return NextResponse.json({ ok: false, error: 'invalid', fields: missing }, { status: 400 });
  }

  // שולפים ספקים פעילים
  const providers = (await prisma.provider.findMany({
    where: { active: true },
    select: {
      id: true,
      email: true,
      categories: true,
      regions: true,
      tags: true,
      minBudget: true,
      maxBudget: true,
      active: true,
      orgName: true,
    },
  })) as unknown as MatchableProvider[];

  // התאמה + דה-דופליקציה + הגבלת כמות
  const shortlistAll = matchProviders(
    { category, subcategory, region, budgetMax: budgetMax ?? undefined, title },
    providers,
  );
  const uniqueTargets = dedupeByEmail(shortlistAll).slice(0, 10);

  let created: { id?: string } | null = null;

  if (live) {
    // בניית אובייקט לבסיס הנתונים — מותאם לסכימה (אם requesterPhone לא קיים אצלך, נסיר)
    const base = {
      title,
      category,
      subcategory,
      budgetMin,
      budgetMax,
      region,
      contactWindow,
      requesterName,
      requesterEmail,
      requesterPhone, // אם אצלך אין עמודה — ה־catch למטה יטפל
      status: 'dispatched' as const,
    };

    try {
      created = await prisma.request.create({ data: base as any });
    } catch {
      const { requesterPhone: _drop, ...rest } = base as any;
      created = await prisma.request.create({ data: rest });
    }

    // שליחת מיילים: שימוש בחתימה sendEmail(to, subject, body)
    await Promise.allSettled(
      uniqueTargets.map((p) => {
        const lines = [
          `קטגוריה: ${category}${subcategory ? `/${subcategory}` : ''}`,
          `אזור: ${region}`,
          budgetMax ? `תקציב מקסימלי: ${budgetMax} ₪` : '',
          '',
          'פרטי יוצר:',
          requesterName,
          requesterEmail,
          requesterPhone || '',
        ].filter(Boolean);

        return sendEmail(
          p.email,
          `NeedMe: בקשה חדשה – ${title}`,
          lines.join('\n'),
        );
      }),
    );
  }

  return NextResponse.json({
    ok: true,
    live,
    requestId: created?.id ?? null,
    matchedProviders: uniqueTargets.length,
  });
}
